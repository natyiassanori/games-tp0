Oi professor, seguem algumas instru��es para o jogo:

- � poss�vel navegar entre um mapa e outro, por�m para voltar para um mapa anterior (por exemplo, da vila para o campo ou
da casa para a vila) � necess�rio apertar a tecla 'espa�o'.
- A casa que d� acesso ao interior � a primeira a esquerda do personagem quando ele chega na vila. Entre pela entrada
 lateral.
